// priority: 1

onEvent("recipes", (event) => {});
