// priority: 1

onEvent("recipes", (event) => {
  event.recipes.createHaunting(["minecraft:netherrack"], ["kubejs:ash_block"]);
});
